from collections import deque

def bfs(src, target):
    # Convert lists to tuples for immutability and fast hashing
    src = tuple(src)
    target = tuple(target)
    
    # Initialize queue with the starting state
    queue = deque([src])
    # Keep track of visited states to avoid revisiting
    visited = set([src])
    # Dictionary to keep track of parent state for reconstructing path
    parent = {src: None}

    while queue:
        current = queue.popleft()  # Get the next state from the queue
        print(current)  # Print current state (can be commented out)

        # Check if we've reached the goal state
        if current == target:
            print("Success!")
            # Reconstruct the path from src to target
            path = []
            while current is not None:
                path.append(current)
                current = parent[current]
            path.reverse()  # Reverse to get the path from src to target
            return path

        # Generate all possible next states from current state
        for move in possible_moves(list(current), visited):
            move = tuple(move)  # Convert list to tuple for hashing
            if move not in visited:
                visited.add(move)          # Mark state as visited
                parent[move] = current     # Save parent for path reconstruction
                queue.append(move)         # Add next state to queue for BFS

    print("No solution found")
    return None

def possible_moves(state, visited):
    # Find the position of the empty tile (represented by 0)
    b = state.index(0)
    moves = []

    # Determine valid moves based on zero's position
    if b not in [0,1,2]:
        moves.append('u')  # Up move is valid if zero not in top row
    if b not in [6,7,8]:
        moves.append('d')  # Down move valid if zero not in bottom row
    if b not in [0,3,6]:
        moves.append('l')  # Left move valid if zero not in left column
    if b not in [2,5,8]:
        moves.append('r')  # Right move valid if zero not in right column

    new_states = []
    # Generate new states for each valid move
    for m in moves:
        new_state = gen(state, m, b)
        # Only include new states not already visited
        if tuple(new_state) not in visited:
            new_states.append(new_state)
    return new_states

def gen(state, m, b):
    # Make a copy of the current state so original isn't modified
    temp = state.copy()

    # Swap the zero with the adjacent tile in the direction m
    if m == 'd':
        temp[b], temp[b+3] = temp[b+3], temp[b]  # Move zero down
    elif m == 'u':
        temp[b], temp[b-3] = temp[b-3], temp[b]  # Move zero up
    elif m == 'l':
        temp[b], temp[b-1] = temp[b-1], temp[b]  # Move zero left
    elif m == 'r':
        temp[b], temp[b+1] = temp[b+1], temp[b]  # Move zero right
    return temp

# Example usage
src = [1,2,3,4,5,6,7,0,8]
target = [1,2,3,4,5,6,7,8,0]

path = bfs(src, target)
if path:
    print("Solution path:")
    for step in path:
        print(step)
