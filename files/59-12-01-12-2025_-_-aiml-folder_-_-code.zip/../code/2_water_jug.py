x = 0
y = 0
m = 4
n = 3
print("initial state =(0,0)")
print("capacities =(4,3)")
print("goal state =(2,y)")

while x != 2:
    r = int(input("enter the rule:"))
    if r == 1:
        x = m
    elif r == 2:
        y = n
    elif r == 3:
        x = 0
    elif r == 4:
        y = 0
    elif r == 5:
        # Pour from x to y (jug1 to jug2)
        t = n - y  # space left in jug2
        if x >= t:
            x -= t
            y = n
        else:
            y += x
            x = 0
    elif r == 6:
        # Pour from y to x (jug2 to jug1)
        t = m - x  # space left in jug1
        if y >= t:
            y -= t
            x = m
        else:
            x += y
            y = 0
    elif r == 7:
        # Pour all from jug1 to jug2 respecting capacity
        t = n - y  # space left in jug2
        if x >= t:
            x -= t
            y = n
        else:
            y += x
            x = 0
    elif r == 8:
        # Pour all from jug2 to jug1 respecting capacity
        t = m - x  # space left in jug1
        if y >= t:
            y -= t
            x = m
        else:
            x += y
            y = 0
    else:
        print("invalid rule")
    print(x, y)
