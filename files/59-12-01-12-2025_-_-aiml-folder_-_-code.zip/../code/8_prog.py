import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder

# Step 1: Load dataset
data = pd.read_csv('enjoysport.csv')
print("=== Dataset ===")
print(data.head(), "\n")

# Step 2: Split data into features (X) and target (y)
X = data.iloc[:, :-1]   # All columns except the last, [all rows , all col excluding last]
y = data.iloc[:, -1]    # Only the last column, [all rows , only last col]

print("=== Features (X) ===")
print(X.head(), "\n")

print("=== Target (y) ===")
print(y.head(), "\n")

# Step 3: Encode categorical data into numbers
encoders = {col: LabelEncoder() for col in X.columns} 
""" create dictionary like {
  'sky': LabelEncoder(),
  'airTemp': LabelEncoder(),
  'humidity': LabelEncoder(),
  'wind': LabelEncoder(),
  'water': LabelEncoder(),
  'forecast': LabelEncoder()
} where each LabelEncoder for each column
You’re making one encoder per column because each column has different types of categories like (warm, cold).
"""

for col in X.columns: #X.columns return a list of column names
    X[col] = encoders[col].fit_transform(X[col])

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)

print("=== Encoded X ===")
print(X, "\n")

print("=== Encoded y ===")
print(y, "\n")

# Step 4: Train the Decision Tree classifier
clf = DecisionTreeClassifier(criterion="entropy")
"""
If all examples belong to one class → entropy = 0 (perfectly pure)
+If examples are 50/50 “yes” and “no” → entropy = 1 (completely mixed)
When the tree splits on a feature (say, “sky”), it calculates how much entropy decreases after the split.
"""
clf.fit(X, y)
print("Decision Tree model trained successfully!\n")

# Step 5: Visualize the decision tree

# Step 6: Predict for a new sample
# Example: sunny, warm, normal, strong, warm, same
inp = [["sunny", "warm", "normal", "strong", "warm", "change"]]
inp_df = pd.DataFrame(inp, columns=X.columns)

# Encode new input
for col in inp_df.columns:
    inp_df[col] = encoders[col].transform(inp_df[col])

# Make prediction
y_pred = clf.predict(inp_df)
predicted_label = label_encoder.inverse_transform(y_pred)[0]

print(f"For input {inp[0]}, prediction = {predicted_label}")
