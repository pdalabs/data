import csv
num_attributes=6 
a=[]
with open('enjoysport.csv','r')as files:
    reader=csv.reader(files)
    a=list(reader)
hypothesis=a[1][:-1]
for i in a:
    if i[-1]=='yes':
        for j in range(num_attributes):
            if i[j]!=hypothesis[j]:
                hypothesis[j]='?'
print(hypothesis)
print("\n the maximally specific hypothesis for a given training examples:\n")
print(hypothesis)