import csv
with open ('enjoysport.csv','r') as f:
     csv_file=csv.reader(f)
     data=list(csv_file)
     s=data[1][:-1]
     print(s)
     g=[['?' for i in range(len(s))] for j in range(len(s)) ]
     print(g)
     for i in data:
          if i[-1]=="yes":
               for j in range(len(s)):
                    if i[j]!=s[j]:
                         s[j]='?'
          elif i[-1]=="no":
               for j in range(len(s)):
                    if i[j]!=s[j]:
                         g[j][j]=s[j]
                    else:
                         g[j][j]="?"
                         print("\n step "+ str(data.index)+1 +"of candidate elimination algorithm ")
                         print(s)
                         print(g)
          gh=[] 
          for i in g:
               for j in i:
                    if j!="?":
                         gh.append(i)
                    break
     print("\n Final specific hypothesis:\n",s)
     print("\n Final General hypothesis:\n",g)